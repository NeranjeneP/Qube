package com.qube.dto;

public class PartnerDto {
String theatre;
String sizeSlabInGb;
String minimumCost;
String costPerGb;
String partnetId;
public String getTheatre() {
	return theatre;
}
public void setTheatre(String theatre) {
	this.theatre = theatre;
}
public String getSizeSlabInGb() {
	return sizeSlabInGb;
}
public void setSizeSlabInGb(String sizeSlabInGb) {
	this.sizeSlabInGb = sizeSlabInGb;
}
public String getMinimumCost() {
	return minimumCost;
}
public void setMinimumCost(String minimumCost) {
	this.minimumCost = minimumCost;
}
public String getCostPerGb() {
	return costPerGb;
}
public void setCostPerGb(String costPerGb) {
	this.costPerGb = costPerGb;
}
public String getPartnetId() {
	return partnetId;
}
public void setPartnetId(String partnetId) {
	this.partnetId = partnetId;
}



}
