package com.qube.dto;

public class CapacityDto {
	String partnetId;
	String capacity;
	public String getPartnetId() {
		return partnetId;
	}
	public void setPartnetId(String partnetId) {
		this.partnetId = partnetId;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	
}
